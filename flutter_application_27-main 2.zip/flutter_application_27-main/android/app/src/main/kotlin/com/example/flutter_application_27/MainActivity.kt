package com.example.flutter_application_27

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
